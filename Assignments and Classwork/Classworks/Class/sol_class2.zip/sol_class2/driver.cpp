#include <iostream>
#include "rectangle.h"

using namespace std;

int main()
{
  Rectangle obj1;
  Rectangle obj2(3,9);

  obj1 = obj2;     

  cout << "Object 1 dimensions "; 
 cout << obj1.get_length() << " X " << obj1.get_width() << endl;  
      

	cout<<"perimeter= "<<obj1.perimeter()<<endl;
	cout<<"area= "<<obj1.area()<<endl;

	return 0;
}




