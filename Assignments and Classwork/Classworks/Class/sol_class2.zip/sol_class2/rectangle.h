#ifndef Rectangle_h
#define Rectangle_h
class Rectangle 
{
public:
	Rectangle (float =1, float =1);
	float get_length();
	float get_width();
	bool set_length(float );
	bool set_width(float W);
	int perimeter();
	double area();
	~Rectangle();
private :
	float Length;
	float Width;
};
#endif