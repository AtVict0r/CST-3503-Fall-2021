class Rectangle 
{
private :
	float Length;
	float Width;

public:
	Rectangle (float, float);
	float get_length();
	float get_width();
	bool set_length(float );
	bool set_width(float );
	
	
};
