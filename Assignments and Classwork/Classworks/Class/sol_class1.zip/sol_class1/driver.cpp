#include <iostream>
#include "rectangle.h"

using namespace std;

int main()
{
  Rectangle obj1(2,4);
  Rectangle obj2(3,9);


  cout << "Object 1 dimensions "; 
 cout << obj1.get_length() << " X " << obj1.get_width() << endl;  
      

	return 0;
}




