#include <iostream>
#include "rectangle.h"
using namespace std;	

Rectangle::Rectangle (float L, float W)
	{
		set_length(L);
		set_width(W);
	}

float Rectangle::get_length() 
{
		return Length;
}

float Rectangle::get_width()
	{
		return Width;
	}

bool Rectangle::set_length(float L)
	{
		if ((L > 0) && (L <=20))
		{
			Length = L;
			return true;
		}
		else
			return false;
	}

bool Rectangle::set_width(float W)
	{
		if ((W > 0) && (W <=20))
		{
			Width = W;
			return true;
		}
		else
			return false;
	}

 
