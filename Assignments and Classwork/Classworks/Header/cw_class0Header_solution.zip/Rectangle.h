class Rectangle { 
// 1. In a header file, create a class Rectangle with 2 private floating data members: length and width. 

private:
float length, // data member             containing length
      width; // data member containing width

public:
// 2. Use constructor that takes two parameters and uses them to initialize the data members. 

Rectangle (float length, float width) {
  setLength(length); // length = length;
  setWidth(width); // width = width; 
}

// 3. Also, provide set and get functions for the length and width attributes. 
bool setLength(float length) {
// The set function should verify that the parameter is larger than 0.0 and less than 20.0. If value is verified, then set functions assigns the value to data member and return true. Otherwise, returns false. 

// member function that sets the length in the object
if ((length > 0.0) && (length < 20.0)) {
  this -> length = length;// store the length
  return true;
} else {
  return false;
}}

// member function that sets the width in the object
bool setWidth(float width) {
// The set function should verify that the parameter is larger than 0.0 and less than 20.0. If value is verified, then set functions assigns the value to data member and return true. Otherwise, returns false. 

if ((width > 0.0) && (width < 20.0)) {
  this -> width = width; // store the width
  return true;
} else {
  return false;
}}

// member function that retrieves the length from the object
float getLength() {
  return length; // return length's value to this function's caller
}

// member function that retrieves the width from the object
float getWidth() {
  return width; // return width's value to this function's caller
}
}; //End class Rectangle