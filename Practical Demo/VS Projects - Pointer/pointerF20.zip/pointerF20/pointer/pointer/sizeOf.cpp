// Fig. 8.14: fig08_14.cpp
// sizeof operator used to determine standard data type sizes.
#include <iostream>
#include <array>
#include <vector>
using namespace std;
/*
void print(int values[]);

int main()
{
   char c; // variable of type char
   short s; // variable of type short
   int i=10; // variable of type int
   long l; // variable of type long
   long long ll; // variable of type long long
   float f=5; // variable of type float
   double d=20; // variable of type double
   long double ld; // variable of type long double
   int array1[ 5 ]{ 31, 28, 31, 30, 31}; // built-in array of int
   //int *ptr = array1; // variable of type int *
   int *ptr = &i;
   array <int, 20> array2;
   vector <int> v1(20);

   cout << "sizeof c = " << sizeof c 
      << "\tsizeof(char) = " << sizeof( char )
      << "\nsizeof s = " << sizeof s
      << "\tsizeof(short) = " << sizeof( short )
      << "\nsizeof i = " << sizeof i
      << "\tsizeof(int) = " << sizeof( int )
      << "\nsizeof l = " << sizeof l
      << "\tsizeof(long) = " << sizeof( long )
      << "\nsizeof ll = " << sizeof ll
      << "\tsizeof(long long) = " << sizeof( long long )
      << "\nsizeof f = " << sizeof f
      << "\tsizeof(float) = " << sizeof( float )
      << "\nsizeof d = " << sizeof d
      << "\tsizeof(double) = " << sizeof( double )
      << "\nsizeof ld = " << sizeof ld
      << "\tsizeof(long double) = " << sizeof( long double )
      << "\nsizeof builtIn array = " << sizeof array1
	  << "\nsizeof array template = " << sizeof array2
	  //<< "\nsizeof vector = " << sizeof (v1)
      << "\nsizeof ptr = " << sizeof ptr << endl;

   cout << "No of elements in array: " << sizeof array1 / sizeof array1[0] << endl;

   cout << "\nsizeof expr (int*double)= " << sizeof (i*d) << endl;
   cout << "returns sizeof highest type (not value)" << endl;
   // print(array1);


} // end main

void print(int values[])
{
	int size = sizeof values / sizeof values[0]; //doesn't work
	cout << "No of elements in para array: " << size << endl;

	for (int count = 0; count < size; count++)
	{
		cout << "Month " << (count + 1) << " has ";
		cout << values[count] << " days.\n";
	}
}
*/