#include <iostream>
using namespace std;
/*
int main()
{
	const int *xPtr;
	
	int y = 0;
	int z = 5;

	xPtr=&y;
	xPtr=&z;
   
	int x = *xPtr;
	cout << *xPtr << endl;

	z=10;
	
	//*xPtr = 7; //error
} // end main
*/