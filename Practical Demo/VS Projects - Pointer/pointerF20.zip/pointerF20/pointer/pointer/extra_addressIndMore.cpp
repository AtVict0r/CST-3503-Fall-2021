#include<iostream>
using namespace std;
/*
int main()
{
	int *p, var1 = 11,var2 = 22, *p2;

	p = &var1;			// p points to var1
	cout<<*p<<endl;
	p = &var2;			// p points to var2
	cout<<*p<<endl;

	*p = 37;		// var2 = 37

	var1 = *p;		// var1 = 37
	cout<< "\n var 1: " << var1 << "\n var 2: " << var2 << endl; 
	
	//p2 = p;			// p2 points to the same place as p
	//var1 = *p2;		// var1 = 37
	
	return 0;
}
*/