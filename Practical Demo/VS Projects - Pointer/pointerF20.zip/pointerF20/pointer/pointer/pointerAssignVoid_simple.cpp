#include <iostream>
using namespace std;
/*
int main()
{	
   int v = 1;
   int b = 6;
   int x;
   double y;

   int *iptr = &v;
   int *i2ptr = &b;
   double *dptr = &y; 

   void *vptr = &y;
   vptr = &v;

   cout << *iptr << "   " << *i2ptr << endl;
	   
   //dptr = iptr; //error
   // cout << *vptr; //error

   i2ptr = iptr;  // both point to same location
   vptr = iptr;
   cout << vptr << endl;

   cout << *iptr << "   " << *i2ptr << endl;
   cout << vptr << "   " << iptr << endl;

   vptr = dptr;
   cout << vptr << "   " << dptr << endl;

   i2ptr++;
   //vptr++;//error

   if (vptr == dptr)
	   cout << "equal\n";
}
*/