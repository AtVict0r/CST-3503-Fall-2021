// Fig. 8.11: fig08_11.cpp
// Attempting to modify a constant pointer to nonconstant data.
#include <iostream>
using namespace std;
/*
int main()
{
   int x =5, y;

   // ptr is a constant pointer to an integer that can
   // be modified through ptr, but ptr always points to the 
   // same memory location.
   
  // int * const ptr; // error as const pointer must be initialized

   int * const ptr = &x; // const pointer must be initialized
   //int * const ptr = NULL; // ok
   //int const *  ptr = &x; // eror
   
   *ptr = 7; // allowed: *ptr is not const
   cout << x << endl;
   cout << *ptr << endl;
   // ptr = nullptr; // error: ptr is const; cannot change
   //ptr = &y; // error: ptr is const; cannot assign to it a new address
} // end main
*/