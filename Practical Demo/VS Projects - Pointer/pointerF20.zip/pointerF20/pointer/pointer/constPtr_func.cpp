// 
#include <iostream>
using namespace std;


void f(int *const); // prototype
//void f(const int *); // prototype

int main() {
   int y=0;

   f(&y); 
}


//void f(const int * xPtr)
void f(int *const xPtr)
{
	int z = 10;
	*xPtr = 100; 
   cout << *xPtr << "\n"; 
   //xPtr = &z; // error: error: xPtr is const; cannot assign to it a new address
   cout << *xPtr << "\n";
}
