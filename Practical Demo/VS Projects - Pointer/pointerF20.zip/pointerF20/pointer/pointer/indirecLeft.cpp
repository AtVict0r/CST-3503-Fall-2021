#include <iostream>
using namespace std;
/*
int main()
{
   int x = 25;    // int variable
   int *ptr;      // Pointer variable, can point to an int
   //cout << *ptr; // // cannot dereference (apply indirection) on uninitialized pointer

   ptr = &x;      // Store the address of x in ptr
   int y = *ptr;  // y=x
   
   cout << x << endl;     // Displays the contents of x
   cout << "y is " << y << endl;  // Displays the contents of x
   
   // Assign 100 to the location pointed to by ptr. This will assign 100 to x.
   *ptr = 100; // x = 100;
   
   cout << "x is " << x << endl; // Displays the contents of x
   //cout << y << endl;
   cout << *ptr << endl;  // Displays the contents of x

   return 0;
}
*/