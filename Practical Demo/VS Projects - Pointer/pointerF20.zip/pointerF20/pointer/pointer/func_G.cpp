// This program uses two functions that accept addresses of
// variables as arguments.
#include <iostream>
using namespace std;
/*
// Function prototypes
void getNumber(int *);
void doubleValue(int *);

int main()
{
   int number = 10;
   int *ptr = &number;
   getNumber(&number); // Call getNumber and pass the address of number
   
   cout << "\nThe value of number after calling func: " << number << endl;
   
   getNumber(ptr);
   cout << "\nThe value of number after calling func: " << number << endl;
   
   doubleValue(&number); // Call doubleValue and pass the address of number.
   
   cout << "\nThat value doubled is " << number << endl;
   return 0;
}

void getNumber(int *para)
{
    cout << "from getnumber func  ";
	cout << *para;
   //cout << "Enter an integer number: ";
   //cin >> *para;
}

// This function multiplies the variable pointed to by val by two.                                                         
void doubleValue(int *val)
{
    //int b = *val;
	//*val = b * 2;
	*val = *val * 2;
}

*/