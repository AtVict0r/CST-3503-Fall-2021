// Fig. 8.4: fig08_04.cpp
// Pointer operators & and *.
#include <iostream>
using namespace std;
/*
int main()
{
   int a = 7; // assigned 7 to a
   int *aPtr = &a; // initialize aPtr with the address of int variable a

   cout << "The address of a is " << &a
      << "\nThe value of aPtr is " << aPtr << endl;
   
   
cout << "\n\nThe value of a is " << a
      << "\nThe value of *aPtr is " << *aPtr << endl;

cout << "\nThe value of *(&a) is " << *(&a) << endl;


 int *bPtr = NULL; // or nullptr
 
 //cout << *bPtr; // cannot dereference (apply indirection) on null pointer

 // &a++; // cannot apply & on an expression
 //&(a + 2); // cannot apply & on an expression

} // end main
*/