#include <iostream>
using namespace std;
/*
int main()
{
	double *xPtr;
	
	int y = 0;
	double z = 5.2;
	
	xPtr= &z;
	//xPtr = 5.0; //error

	//xPtr=&y; // error as y is int
	
	cout << *xPtr << endl;
	*xPtr=4.1; // changes the variable z
	cout << z << endl;
	
} // end main
*/