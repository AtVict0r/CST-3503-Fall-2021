#include <iostream>
using namespace std;

/*
void swap(int *x, int *y)
{		int temp;
		temp = *x;
		*x = *y;
		*y = temp;
		//cout << num1;
}

int main()
{

	int num1 = 2, num2 = -3;

  cout << "Here are the values of num1 and num2:\n";
	cout << num1 << endl;
   cout << num2 << endl;
	
	swap(&num1, &num2);

   cout << "After calling swap, the values of num1 and num2 are:\n";
   cout << num1 << endl;
   cout << num2 << endl;
}
*/