#include <iostream>
using namespace std;

/*
int main()
{
   int v[5] = { 1,2, 3, 4, 5 };
   int x;
   int *vptr = &v[0];
   int *v2ptr = &v[2];
   
   //x = v2ptr + vptr; // gives error
   // x = v2ptr � vptr;  // gives error
   // cout << v2ptr � vptr << endl; // gives error
   //v2ptr-=vptr; // gives error
   //v2ptr+=vptr; // gives error
   cout << "\n" << *vptr << endl;
   cout << "\n" << x << endl;
   
   v2ptr = vptr;  // both point to same location
   *vptr = 10;
   cout << *v2ptr; 
}
*/