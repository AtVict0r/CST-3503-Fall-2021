#include <iostream>
using namespace std;

/*
int main()
{
   
	
	int v[5] = { 1,2, 3, 4, 5 };
	int b[5] = { 2,4, 6, 8, 10 };

   int x;
   int *iptr = &v[0];
   int *i2ptr = &b[2];
   double d=5;
   double *dptr =&d; 

   void *vptr = &v[3];

   cout << *iptr << "   " << *i2ptr << endl;
	   
   

   //dptr = iptr; //error
   // cout << *vptr; //error

   i2ptr = iptr;  // both point to same location
   vptr = iptr;
   cout << vptr << endl;

   cout << *iptr << "   " << *i2ptr << endl;

   cout << vptr << "   " << iptr << endl;

   vptr = dptr;
   cout << vptr << endl;

   vptr = &d;
   cout << vptr << endl;

}
*/