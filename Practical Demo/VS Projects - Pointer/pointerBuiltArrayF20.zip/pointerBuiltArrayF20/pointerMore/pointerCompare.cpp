// This program uses a pointer to display the contents 9-10g
// of an integer array.
#include <iostream>
using namespace std;

int main()
{
   int set[3] = {5, 10, 15};
   int *nums = set;     // int *nums = &set[0]

   // Display the numbers in the array.
   cout << "The numbers in set are:\n";
   cout << *nums << " ";   // Display first element
   while (nums < &set[2])
   {
      // Advance nums to point to the next element.
      nums++;
      // Display the value pointed to by nums.
      cout << *nums << " ";
   }
   
   // Display the numbers in reverse order.
   cout << "\nThe numbers in set backward are:\n";
   
   //if (nums != nullptr)
	if (nums != NULL)
	   cout << *nums << " ";   // Display last element
	
   int *ptr = &set[0];
   
   while (nums > ptr)     // nums > &set[0]
   {
      // Move backward to the previous element.
      nums--;
      // Display the value pointed to by nums.
      cout << *nums << " ";
   }
   cout << endl;
   return 0;
}
