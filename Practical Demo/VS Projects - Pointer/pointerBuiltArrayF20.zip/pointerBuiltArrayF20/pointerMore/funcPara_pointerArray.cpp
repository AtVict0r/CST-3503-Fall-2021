// This program displays the number of days in each month.
#include <iostream>
using namespace std;
/*
void print( int *values, int size )
{
	for (int count = 0; count < size; count++)
     {
                    cout << "Month " << (count + 1) << " has ";
                    cout << values[count] << " days.\n";
     }   //pointer/subscript notation, values[count] = days[count]
}

int main()
{
   //const int MONTHS = 5;
   int days[3] = { 31, 28, 31};
 
   //days[1] = 29;
   print(days,3);
}

*/