// This program uses subscript notation with a pointer variable and
// pointer notation with an array name. 9-7G
#include <iostream>
#include <iomanip>
using namespace std;
/*
int main()
{
   const int NUM_COINS = 3;
   double coins[NUM_COINS] = {0.05, 0.1, 0.25};
   double *doublePtr;   // Pointer to a double
   int count;           // Array index

   // Assign the address of the coins array to doublePtr.
   doublePtr = coins; // doublePtr = &coins[0]

   // Display the contents of the coins array. Use subscripts with pointer!
   cout<< "POINTER subscript notation \n";
   cout << "Here are the values in the coins array:\n";
   for (count = 0; count < NUM_COINS; count++)
      cout << doublePtr[count] << " "; // doublePtr[count]=coins[count]

   // Display the contents of the array again, but this time
   cout << "\n\n use pointer offset notation"; 
   cout << "\n And here they are again:\n";
   for (count = 0; count < NUM_COINS; count++)
      cout << *(doublePtr + count) << " "; // *(doublePtr + count) = coins[count]
   cout << endl;


   // Display the contents of the array again, but this time
   cout << "\n use pointer offset notation with the array name!";
   cout << "\nAnd here they are again:\n";
   for (count = 0; count < NUM_COINS; count++)
      cout << *(coins + count) << " "; // *(coins + count) = coins[count]
   cout << endl;
   return 0;
}
*/