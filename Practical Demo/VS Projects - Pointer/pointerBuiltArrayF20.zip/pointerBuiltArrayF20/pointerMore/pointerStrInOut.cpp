// This program demonstrates how cin can read a string into
// a pointer-based .
#include <iostream>

using namespace std;
/*
int main()
{
   char color[] = "blue";
   //char color[5] = "blue";
   char *colorPtr = "green";

   char ch[2]  = { 'a', 'z'};

   cout << "Color is " << color << endl;
   cout << "Color is " << colorPtr << endl;
   cout << "Letter " << colorPtr[1] << endl;

   cout << "What is your name? ";
   cin >> color;
   //cin >> colorPtr; // error
   cout << "Good morning " << color << endl;
   cout << "Letter " << color[1] << endl;
 
cout << "Hello " << ch << endl; //cin and cout do not provide similar capabilities for other built-in array types.
cout << "What is your initial? ";
cin >> ch;
cout << ch;
return 0;
}
*/