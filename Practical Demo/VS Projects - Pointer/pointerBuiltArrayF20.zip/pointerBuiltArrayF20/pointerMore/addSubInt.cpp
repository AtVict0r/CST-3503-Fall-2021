// This program uses a pointer to display the contents of an array.
#include <iostream>
using namespace std;
/*
int main()
{
   const int SIZE = 5;
   int set[SIZE] = {5, 10, 15, 20, 25};
   //int set[SIZE] = {5, 10, 15};
   int *numPtr;   // Pointer
   int count;     // Counter variable for loops

   // Make numPtr point to the set array.
   numPtr = set; // numPtr = &set[0] 
   cout << "size of datatype of pointer is  " << sizeof(numPtr) << "\n ";
   // Use the pointer to display the array contents.
   
      cout << "initial value " << *numPtr << " ";
	  cout << "initial address " << numPtr << "\n ";
	  
	  numPtr = numPtr + 2; //
	  cout << "value after adding 2: " << *numPtr << "\n ";
	  cout << "address increases by 2*4 bytes after adding: " << numPtr << "\n ";
  
   // Display the array contents in reverse order.
   cout << "\n\n";
      numPtr = numPtr - 2; // numPtr-=2;
      cout << "value after subtracting 2: " << *numPtr << "\n ";
	  cout << "address decreases by 2*4 bytes after subtracting: " << numPtr << " ";
   cout << "\n";

   numPtr += 3; // numPtr = numPtr + 3; 						
   cout << "value after adding 3: " << *numPtr << "\n ";
   cout << "address increases by 3*4 bytes after adding: " << numPtr << "\n ";

   return 0;
}
*/