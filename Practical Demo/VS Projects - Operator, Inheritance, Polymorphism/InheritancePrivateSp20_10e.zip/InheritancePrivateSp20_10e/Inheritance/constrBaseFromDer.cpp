#include <iostream>
using namespace std;
/*
class BaseClass
{
public:
   BaseClass(int i )  // Constructor
      { 
		  cout << "This is the BaseClass constructor with id " << i << "\n"; 
      }   
};

class DerivedClass : public BaseClass
{
public:
   DerivedClass( )  // Constructor
   : BaseClass(100)    // must call base constructor as base has no default constructor 
      { 
		  //BaseClass(100); // cannot call constructor from body
		  cout << "This is the DerivedClass constructor.\n"; 
      }

};

void main()
{
   DerivedClass object;
   // DerivedClass object(100); // cannot use base constructor
}
*/