// This program demonstrates the order in which base and
// derived class constructors and destructors are called.
#include <iostream>
using namespace std;

// BaseClass declaration         *
/*
class BaseClass
{
public:
   
BaseClass()  // Default Constructor
      { cout << "This is the BaseClass default constructor.\n"; }
	  
   ~BaseClass() // Destructor
      { cout << "This is the BaseClass destructor.\n"; }
};

// DerivedClass declaration      *

class DerivedClass : public BaseClass
{
public:
   DerivedClass()  // Default Constructor
	   // auto calls base's default constructor
      { cout << "This is the DerivedClass constructor.\n"; }

   ~DerivedClass()  // Destructor
      { cout << "This is the DerivedClass destructor.\n"; }
};


int main()
{
	cout << "We will now define a DerivedClass object.\n";

	DerivedClass object; // calls base's default constructor, then derived class's constructor 

	cout << "The program is now going to end.\n";
	return 0;
}
*/