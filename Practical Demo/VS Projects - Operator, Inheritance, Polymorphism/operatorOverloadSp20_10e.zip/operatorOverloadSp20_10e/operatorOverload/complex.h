#ifndef Complex_H
#define Complex_H

#include<iostream>
#include<fstream>
using namespace std;

class Complex
{
//friend double operator-(Complex & c1, Complex & c2); 
//friend double operator++(Complex & c1); 

public:
	double real;
	double img;

public:
	Complex(double a=0, double b=0)
		:real(a),img(b)
	{
	}
	
    double operator+(Complex &c)
    {
        double sum; 
		sum = real + c.real;
        return sum;
    }

	
	Complex & operator*(Complex &c)
    { 
		Complex mul;
        mul.real = real * c.real;
        mul.img =  img * c.img;
        return mul;
    }

	bool operator!()
	{
       if (img==0)
          return true;
	   else
          return false;
	}

	double operator-=(double d)
    {
		real = real - d;
        return real;
    }
	/*
	double operator++()
	{
		real = real + 1;
		return real;
	}
	*/
};

#endif