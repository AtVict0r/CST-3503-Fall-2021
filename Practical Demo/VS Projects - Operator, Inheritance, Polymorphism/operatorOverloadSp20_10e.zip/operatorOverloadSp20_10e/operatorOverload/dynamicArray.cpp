// This program totals and averages the sales figures for any
// number of days. The figures are stored in a dynamically
// allocated array.
#include <iostream>
#include <iomanip>
#include "complex.h"
using namespace std;
/*
int main()
{
    double *sales, // To dynamically allocate an array
    total = 0.0,   // Accumulator
    average;       // To hold average sales
    int numDays=3,   // To hold the number of days of sales
        count;     // Counter variable

	
    // Get the number of days of sales.
    //cout << "How many days of sales figures do you wish ";
    //cout << "to process? ";
    //cin >> numDays;
	

    // Dynamically allocate an array large enough to hold
    // that many days of sales amounts.
	sales = new double[numDays]{1.1, 2.2, 3.3};
	//sales = new double[numDays]();
	for (count = 0; count < numDays; count++)
    {
     cout << sales[count] << " ";
    }
	cout << endl;
    
    // Free dynamically allocated memory
  
    delete [] sales;
    sales = nullptr; // Make sales point to null.

	double *value = new double(2.5);

	cout << "double " << *value << endl;

	Complex *cx = new Complex(5, 10);

	cout << "Complex object  " << (*cx).real << " " << (*cx).img << endl;
	
	Complex *cp = new Complex[3]; // dynamic array of objects
	cp[1].real = 2.1;
	cout << "Complex array  " << cp[1].real << " " << cp[1].img << endl;


    return 0;
}
*/