#include <iostream> // allows program to perform input and output
using namespace std;
/*
class SomeClass
	{ 
	private:
		double num;
		int *value;

	public:
		  SomeClass(int val = 0, double d=0)
			{
			  value=new int (val); 
			  // *value = val;
			  num = d;
		    } 
		 //copy constructor
    
		  SomeClass(const SomeClass &obj)
	      {
		   cout << "I am copy constructor\n";
		   num =   obj.num;
           value = new int;
		  *value = *obj.value;
	     }
	  
		  double getNum()
          { 
			return num; 
		  }
		  int getVal()
          { 
			return *value; 
		  }
		  void setVal(int v)
          { 
			  *value = v; 
		  }

        SomeClass & print(SomeClass &sc) //copy Constructor not called as ref
		//SomeClass print(SomeClass sc)
		  {
			cout << "\n Printing Data members via print()\n";
			 cout << sc.getNum() << endl;
             cout << sc.getVal() << endl; 
			 return sc;
		  }

     
	};

void main()
{
 SomeClass object1(5,3.2);
 //SomeClass object2 = object1; //calls copy Constructor
 SomeClass object2(object1); //calls copy Constructor
 SomeClass object3;
 object3 = object1; // doesn't call copy Constructor as no object is created
 cout << "\n Data members of object2\n";
 cout << object2.getNum() << endl;
 cout << object2.getVal() << endl;
 
 object2.setVal(13);
 cout << "\n Pointer Data member of both objects\n";
 cout << object1.getVal() << endl; 
 cout << object2.getVal() << endl;

 object3=object1.print(object2); //calls copy Constructor twice
 cout << "\n Data members of object3\n";
 cout << object3.getNum() << endl; 
 cout << object3.getVal() << endl;
}
*/