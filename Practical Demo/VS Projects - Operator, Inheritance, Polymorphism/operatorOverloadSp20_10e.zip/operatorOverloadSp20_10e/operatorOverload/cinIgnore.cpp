#include <iostream>
using namespace std;

/*
int main()
{

  int a, b, c, d;
  cin >> a >> b;
  
  cin.ignore(100, '\n');

  cin >> c;

  cin.ignore(2);
  cin >> d;

  cout << a << " " << b << " " << c << " " << d;
}

*/