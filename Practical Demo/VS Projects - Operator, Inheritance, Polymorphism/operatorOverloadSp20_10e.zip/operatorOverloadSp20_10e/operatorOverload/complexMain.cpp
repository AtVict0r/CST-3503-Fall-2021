#include <iostream>
#include "complex.h"
using namespace std;
/*
double operator-(Complex & , Complex & );
double operator++(Complex & );

int main()
{
  Complex c1(2,4);
  Complex c2(1,2);
  Complex c3(0,0);
  Complex c4(2,0);
  cout<< "c1 + c2: ";
  cout<< c1 + c2<<endl; // calls c1.operator+(c2)
  cout<< "c1 - c2: ";
  cout<< c1 - c2<<endl; // calls operator-(c1,c2)
  // cout<< c1 / c2<<endl; error as no operator/ func defined

  c3 = c1 * c2;  // calls c1.operator*(c2), c3=mul
  cout<< "After c3 = c1 * c2: data members of c3 are ";
  cout << c3.real << " " << c3.img << endl; // allowed as real & img are public data members

  //c4 = c4 - 2; // error as operator- has no int/double parameter 

  c4-=2; // calls c4.operator-=(2)
  cout<< "After c4-=2: real data member of c4 is ";
  cout << c4.real << endl;
 
  cout << "!c4: ";
  if (!c4)  // calls c4.operator!()
    cout << "true" << endl;

  //cout << "c4++: ";
  //c4++;  // error as post inc is implemented differently
  //cout << c4.real << endl;

  cout << "++c4: ";
  cout << ++c4 << endl;  // calls operator++(c4) for pre inc
  cout << "After ++c4: real data member of c4 is ";
  cout << c4.real << endl;

}

double operator-(Complex & p, Complex & q)
{
  double diff;
  diff = p.real - q.real;
  return diff;	
}


double operator++(Complex & x)
{
  x.real = x.real + 1;
  return x.real;
}

*/