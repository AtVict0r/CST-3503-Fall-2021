// Fig. 12.19: fig12_19.cpp
// Demonstrating downcasting and runtime type information.
// NOTE: You may need to enable RTTI on your compiler
// before you can compile this application.
#include <iostream>
#include <iomanip>
#include <vector>
#include <typeinfo>
#include "Employee.h"
#include "SalariedEmployee.h" 
#include "CommissionEmployee.h"  
#include "BasePlusCommissionEmployee.h" 
using namespace std;

int main()
{
   // set floating-point output formatting
   cout << fixed << setprecision( 2 );   
   
   // create vector of three base-class pointers
   vector < Employee * > employees( 3 );

   // initialize vector with various kinds of Employees
   employees[ 0 ] = new SalariedEmployee( 
      "John", "Smith", "111-11-1111", 800 );
   employees[ 1 ] = new CommissionEmployee( 
      "Sue", "Jones", "333-33-3333", 10000, .06 );
   employees[ 2 ] = new BasePlusCommissionEmployee( 
      "Bob", "Lewis", "444-44-4444", 5000, .04, 300 );

   // polymorphically process each element in vector employees
   //for ( Employee *employeePtr : employees ) 
   for (int i = 0; i< employees.size(); i++)
   {
      employees[i]->print(); // output employee information
	  //cout << employees[i]->toString() << endl; // output employee
      cout << endl;

      // downcast; returns nullptr if employees[i] doesn't point to a BasePlusCommissionEmployee
      BasePlusCommissionEmployee *derivedPtr =
         dynamic_cast < BasePlusCommissionEmployee * >( employees[i] );

	  //BasePlusCommissionEmployee *derivedPtr = employees[i]; // cannot assign base * to derived *

	  //employees[i]->getBaseSalary(); // cannot call func that is only in derived, using base *

      // determine whether element points to a BasePlusCommissionEmployee 
      if ( derivedPtr != nullptr ) // true for "is a" relationship
      {
         double oldBaseSalary = derivedPtr->getBaseSalary();
         cout << "old base salary: $" << oldBaseSalary << endl;
         derivedPtr->setBaseSalary( 1.10 * oldBaseSalary );
         cout << "new base salary with 10% increase is: $" 
            << derivedPtr->getBaseSalary() << endl;
      } // end if
      
      cout << "earned $" << employees[i]->earnings() << "\n\n";
   } // end for   
 
   // release objects pointed to by vector�s elements
   //for ( const Employee *employeePtr : employees ) 
   for (int i = 0; i< employees.size(); i++)
   {
      // output class name
      
	   const type_info &ti = typeid( *employees[i] );
	   cout << "deleting object of " 
         << ti.name() << endl;

	   //cout << "deleting object of " 
        // << typeid( *employees[i] ).name() << endl;

      delete employees[i];
   } // end for
} // end main

