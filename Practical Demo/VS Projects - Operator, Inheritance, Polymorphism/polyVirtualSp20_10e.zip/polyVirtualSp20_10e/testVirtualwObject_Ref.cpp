// Modified Fig. 12.6: fig12_06.cpp
// Invoking virtual function using base-class reference & object
#include <iostream>
#include <iomanip>
#include "CommissionEmployee.h"
#include "BasePlusCommissionEmployee.h" 
using namespace std;
/*
int main()
{
   // create base-class object
   CommissionEmployee commissionEmployee( 
      "Sue", "Jones", "222-22-2222", 10000, .06 );

   // create derived-class object
   BasePlusCommissionEmployee basePlusCommissionEmployee(
      "Bob", "Lewis", "333-33-3333", 5000, .04, 300 );


   // set floating-point output formatting
   cout << fixed << setprecision( 2 );


// create base-class reference & aim it at derived-class object
   
CommissionEmployee &commEmpRef = basePlusCommissionEmployee; 

   cout << "\n\nCalling virtual function print with base-class reference";
   cout   << "\nto derived-class object invokes derived-class ";
   cout   << "print function:\n\n";

   // polymorphism; invokes BasePlusCommissionEmployee's print;
   // base-class reference to derived-class object
   commEmpRef.print();
   cout << endl;

   commissionEmployee = basePlusCommissionEmployee;
   cout << "\n No polymorphism when invoking virtual print function on base-class object having derived object\n\n ";
         commissionEmployee.print(); // static binding
   cout << endl;

   //BasePlusCommissionEmployee &basecommEmpRef = commissionEmployee;
   //basePlusCommissionEmployee = commissionEmployee;



} // end main
*/