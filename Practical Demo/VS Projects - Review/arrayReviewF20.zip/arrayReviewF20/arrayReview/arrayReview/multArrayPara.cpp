// Fig. 7.20: fig07_20.cpp
// Initializing multidimensional arrays.
#include <iostream>
#include <array>
using namespace std;

const int rows = 2;
const int columns = 3;
void printArray( const array< array< int, columns >, rows>  );
/*
int main()
{
   array< array< int, columns >, rows > array1 = { 1, 2, 3, 4, 5, 6 };
   array< array< int, columns >, rows > array2 = { 1, 2, 3, 4, 5 };

   cout << "Values in array1 by row are:" << endl;
   printArray( array1 );

   cout << "\nValues in array2 by row are:" << endl;
   printArray( array2 );
} // end main

// output array with two rows and three columns

void printArray( const array< array< int, 3 >, 2>  a )
{
  
for ( int row = 0; row < a.size(); ++row ) 
{
   for ( int column = 0; column < a[ row ].size(); ++column )
      cout << a[ row ][ column ] << ' ';
   cout << endl;
} // end outer for

} // end function printArray
*/

/*
// using nested rangeFor to output array with two rows and three columns
void printArray( const array< array< int, columns >, rows>  a )
{
   // loop through array's rows
   for ( auto const &row : a )
   {    
      // loop through columns of current row
      for ( auto const &element : row )
         cout << element << ' ';

      cout << endl; // start new line of output
   } // end outer for
} // end function printArray
*/