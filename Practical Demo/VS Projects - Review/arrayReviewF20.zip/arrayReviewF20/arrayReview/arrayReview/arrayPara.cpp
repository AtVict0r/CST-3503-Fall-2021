#include <iostream>
#include <array>
using namespace std;
/*
void twice( array<int, 5> &set );

int main ()
{
  array< int, 5 > items = { 1, 2, 3, 4, 5 };
  twice(items);

  for ( int grade = 0; grade < 5; grade++ )
       cout << items[grade] << " ";
  cout<<endl;                // items array didn�t change
}

void twice( array<int, 5> &set ) 
{
for ( int grade = 0; grade < set.size(); grade++ )
      set[grade] = set[grade] * 2;

for ( int grade = 0; grade < 5; grade++ )
       cout << set[grade] << " ";
cout<<endl;
} // end function
*/