#include <iostream>
#include <vector>
using namespace std;
/*
int main()
{ 
	vector <int> v1(2);
	vector <int> v2;
	vector <int> v3(5,2); // size 5 and all elements initialized to 2
	vector <int> v4(3);

	vector <int> v5{ 1,2,3 };

	v1[0]= 4;
	v1[1]= 5;
	
    //v2[0] = 4 ; // error as v2 is initially empty  

      v2.push_back(4);
      v2.push_back(5);
      v2.push_back(2); 
	
    cout << "Elements of v1\n";
    cout << v1[0]<< "  " << v1[1]<< endl;	

	cout << "Elements of v2\n";
cout << v2[0]<< "  " << v2[1]<<"  " << v2[2] << endl;
//cout << v2[3]; // error as v2 is increased upto size 3

cout << "Size of v2: "<< v2.size() << endl;	
v2 = v1;

cout << "Elements of v2 after assignment\n";
cout << v2[0]<< "  " << v2[1]<<"  " <<  endl;
	 
cout << "Size of v2 decreases after assignment: " << v2.size() << endl;  // size of v2 decreases

v4 = v3;
 
cout << "Size of v4 increases after assignment: " << v4.size() << endl;  // size of v4 increases 

 cout << "Elements of v4 after assignment\n";
  for (int i=0; i<v4.size(); i++)
	   cout << v4[i] << " ";

  cout << "\n";

  cout << "Elements of v5\n";
  for (int i = 0; i<v5.size(); i++)
	  cout << v5[i] << " ";

  cout << "\n";

}
*/