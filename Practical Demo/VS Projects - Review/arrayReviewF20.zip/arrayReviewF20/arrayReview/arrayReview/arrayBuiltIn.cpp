// This program displays the number of days in each month.
#include <iostream>
using namespace std;
/*
void print( int values[], int size )
{
	for (int count = 0; count < size; count++)
                 {
                    cout << "Month " << (count + 1) << " has ";
                    cout << values[count] << " days.\n";
                 }
	        values[size-1] = 20;
			cout << endl;
}

int main()
{
   const int MONTHS = 12;
   int days[MONTHS] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
 
   days[1] = 29;
   print(days,12);

   for (int count = 0; count < 12; count++)
                 {
                    cout << "Month " << (count + 1) << " has ";
                    cout << days[count] << " days.\n";
                 }

}
*/