#include <iostream>
using namespace std;
/*
int main()
{
  int count;

for (count = 1; count <= 5; ++count)
  cout << "Hello" << endl;

}
*/