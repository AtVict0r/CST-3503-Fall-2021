#include <iostream>
using namespace std;

/*
void useLocal(); // function prototype

int main()
{
   useLocal(); // calling useLocal function
   return 0;
} // end main

// function definition 
void useLocal()
{
   cout << "\nThis is useLocal method " << endl;
} // end function useLocal
*/