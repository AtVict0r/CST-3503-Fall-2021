#include <iostream>  
using namespace std;
/*
void print()
{
  static int x = 15;
  int y = 8;
  x++; 
  y++;
  cout << x << "  " << y << "  ";
  cout << endl;
} 

int main()
{ 
   print();
  print();
  // cout << x;
}
*/