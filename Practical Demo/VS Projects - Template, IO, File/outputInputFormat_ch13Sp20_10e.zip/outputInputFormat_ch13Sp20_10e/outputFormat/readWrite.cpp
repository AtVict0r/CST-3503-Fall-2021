// Fig. 13.5: fig13_05.cpp 
// Unformatted I/O using read, gcount and write.
#include <iostream>
using namespace std;
/*
int main()
{
   const int SIZE = 80;
   char buffer[ SIZE ]; // create array of 80 characters

   // use function read to input characters into buffer
   cout << "Enter a sentence:" << endl;
   cin.read( buffer, 20 );

   // use functions write and gcount to display buffer characters
   cout << endl << "The sentence entered was:" << endl;
   cout.write( buffer, cin.gcount() );
   cout << endl;

   cout << "Number of char read was:" << cin.gcount() << endl;

   cin.read( buffer, 30);
   cout << endl << "The sentence read was:" << endl;
   
   cout.write( buffer, 30);
   cout << "\nNumber of char read was:" << cin.gcount() << endl;

} // end main
*/