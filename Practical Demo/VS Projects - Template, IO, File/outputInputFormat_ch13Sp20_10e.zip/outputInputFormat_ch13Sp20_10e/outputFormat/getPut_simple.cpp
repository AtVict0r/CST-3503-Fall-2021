#include <iostream>
using namespace std;
/*
int main()
{
   char character; 

   // prompt user to enter line of text
   cout << "Enter 5 characters using get and put:" << endl;

   for (int i = 0; i < 5; i++)
   {
	   cin.get(character);   // a 1$[enter]
	   cout.put( character );
   }

    
   cout << "Enter 5 characters using cin and cout:" << endl;

   for (int i = 0; i < 5; i++)
   {
	   cin >> character;   // a 1$[enter]
	   cout << character;
   }

   cout << "\nOutput mult characters using put:" << endl;
   cout.put('A').put('\n');


} // end main
*/