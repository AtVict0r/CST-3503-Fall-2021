// Fig. 13.08: fig13_08.cpp 
// width member function of class ios_base.
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main()
{
   int widthValue = 4;
   //char sentence[ 10 ];
   string sentence;

   cout << "Enter a sentence:" << endl;
   //cin.width( 5 ); // input only 5 characters from sentence
   cin >> setw(4);
   //cin.width( 4 );

   // set field width, then display characters based on that width 
   while ( cin >> sentence ) 
   {
      cout.width( widthValue++ );
      cout << sentence << endl;
      //cin.width( 5 ); // input 5 more characters or upto space from sentence
      cin.width( 4 );
   } // end while

   //cout.width(10);
   cout << setw(10);
   cout << "\ncurrent width is " << cout.width(); // returns current width
   cout << "\ncurrent width is " << cout.width() << endl; // returns current default width
}
