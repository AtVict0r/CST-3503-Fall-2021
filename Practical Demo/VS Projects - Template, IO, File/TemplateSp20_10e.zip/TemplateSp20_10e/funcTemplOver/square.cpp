#include<iostream>
#include<string>
using namespace std;
/*
template <class T>
T square(T x)
{ 
 return x*x;
}


int main()
{ int x = 10;
  float y = 3.3;
  double z = 4.5;
  string str = "Hello";

 cout<<"square of x " << square(10)<<endl;
 cout<<"square of y "<<square(y)<<endl;
 cout<<"square of z "<<square(z)<<endl;

 // cout<<"square of string "<<square(str)<<endl; // error as string doesnt support *

 return 0;
}
*/