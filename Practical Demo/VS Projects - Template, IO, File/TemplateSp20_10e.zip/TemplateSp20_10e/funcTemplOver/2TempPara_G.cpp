// This program demonstrates a function template
// with two type parameters. 16-9G
#include <iostream>
using namespace std;
/*
//template <class T1, class T2, class T3> // error as T3 is not used as parameter
template <class T1, class T2>
int largest(T1 var1, T2 var2)
{
   if (sizeof(var1) > sizeof(var2))
      return sizeof(var1);
   else
      return sizeof(var2);
}

int main()
{
   int i = 0;
   char c = ' ';
   float f = 0.0;  
   double d = 0.0;
   int j = 4;

   cout << "Comparing an int and a double, the largest\n"
        << "of the two is " << largest(i, d) << " bytes.\n";

   cout << "Comparing an char and a float, the largest\n"
        << "of the two is " << largest(c, f) << " bytes.\n";

   cout << "Comparing an char and a int, the largest\n"
        << "of the two is " << largest(j, c) << " bytes.\n";

   return 0;
}
*/