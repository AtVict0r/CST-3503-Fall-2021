#include<iostream>
#include <string>
using namespace std;

/*	

template <class T, int P>
T mult(T x, P y  )
{ return x*y;}

template <class T>
T square(T x = 10)
{
 //cout << "overload "; 
 return x*x;
}




int main()
{ int x = 10;
  float y = 3.3;
  double z = 4.5;
  string str = "hello";


 cout<<"square of x: "<<square(10)<<endl;
 cout<<"square of y: "<<square(y)<<endl;
 cout<<"square of z: "<<square(z)<<endl;
 //cout<<"square: "<<square()<<endl;
 
 cout<<"mult of z: "<<mult(y,10)<<endl;

 
 
 return 0;
}
*/