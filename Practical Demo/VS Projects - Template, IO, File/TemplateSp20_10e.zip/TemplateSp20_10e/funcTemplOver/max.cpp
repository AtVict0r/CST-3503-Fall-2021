// Fig. 6.26: fig06_26.cpp
// Function template maximum test program.
#include <iostream>
#include <string>
#include "maximum.h" // include definition of function template maximum
using namespace std;
/*
int main()
{
   // demonstrate maximum with int values
   int int1, int2, int3;

   cout << "Input three integer values: ";
   cin >> int1 >> int2 >> int3;

   // invoke int version of maximum
   cout << "The maximum integer value is: "
      << maximum( int1, int2, int3 );        

   // demonstrate maximum with double values
   double double1, double2, double3;

   cout << "\n\nInput three double values: ";
   cin >> double1 >> double2 >> double3;

   // invoke double version of maximum
   cout << "The maximum double value is: "
      << maximum( double1, double2, double3 );
   //  maximum( double1, int2, double3 );   //  error as all parameter of same template type
   // demonstrate maximum with char values
   char char1, char2, char3;

   cout << "\n\nInput three characters: ";
   cin >> char1 >> char2 >> char3;

   // invoke char version of maximum
   cout << "The maximum character value is: "
      << maximum( char1, char2, char3 ) << endl;

   // demonstrate maximum with string values
   string str1, str2, str3;

   cout << "Input three strings: ";
   cin >> str1 >> str2 >> str3;

   // invoke string version of maximum, works as string supports >
   cout << "The maximum string value is: "
      << maximum( str1, str2, str3 );

   cout << endl;
} // end main

*/