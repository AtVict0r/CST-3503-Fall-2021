#include <iostream>
#include <string>
#include <fstream> // contains file stream processing types
#include <cstdlib> // exit function prototype
using namespace std;
/*
int main()
{
   // ofstream constructor opens file                
   ofstream outClientFile( "clients.txt", ios::out );
	//ofstream outClientFile;
    //outClientFile.open("S:\clients.txt", ios::out);
	//outClientFile.open("clients.txt", ios::app);

	outClientFile.clear(); // not needed
	outClientFile.seekp(2);

   // exit program if unable to create file
   if ( !outClientFile ) // overloaded ! operator
   {
      cerr << "File could not be opened" << endl;
      exit( EXIT_FAILURE );
   } // end if

   cout << "Enter the account, name, and balance." << endl
      << "Enter end-of-file to end input.\n? ";

   int account; // the account number
   string name; // the account owner's name
   double balance; // the account balance

   // read account, name and balance from cin, then place in file
   while ( cin >> account >> name >> balance )
   {
      outClientFile << account << ' ' << name << ' ' << balance << endl;
      cout << "? ";
   } // end while

   cout << outClientFile.tellp() << endl;
   //outClientFile.clear(); // 
   outClientFile.seekp(0,ios::beg);
   outClientFile.seekp(3,ios::cur);
   outClientFile.seekp(2,ios::cur);
   cout << outClientFile.tellp() << endl;
   outClientFile.seekp(0,ios::end);
   cout << outClientFile.tellp() << endl;
   outClientFile.seekp(2,ios::end);
   cout << outClientFile.tellp() << endl;

   outClientFile << "adding data" << endl;
   outClientFile << 900 << ' ' << "Khan" << ' ' << 1000 << endl;

   outClientFile.seekp(-3, ios::end);
   cout << outClientFile.tellp() << endl;

} // end main
*/