#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;
/*
int main()
{
ofstream dataFile;


dataFile.open("updateSeq.txt", ios::app);		// Open in output mode
dataFile.clear();
dataFile.seekp(0, ios::beg);

dataFile << "300 Worthington 0.00" <<endl;
cout << "Done.\n";
dataFile.close();				// Close the file
return 0;
}
*/